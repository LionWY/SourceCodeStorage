#include <sys/cdefs.h>
__FBSDID("$FreeBSD: src/lib/libc/string/strrchr.c,v 1.2 2002/03/22 21:53:19 obrien Exp $");

#define	STRRCHR
#include "rindex.c"
